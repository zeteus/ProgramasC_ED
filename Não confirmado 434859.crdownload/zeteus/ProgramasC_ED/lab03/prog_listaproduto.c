#include "listaproduto.h"

int main(){
    tProduto prod;
    tLista lista;
    int continua;

    /*Cria a lista*/
    FazVazia(&lista);
    
    do{
        criaProduto(&prod); /*Cria um produto*/
        printf("\nDESEJA INCLUIR OUTRO PRODUTO?\n(1 - PARA CONTINUAR, 0 - PARA PARAR)");
        scanf(" %d", &continua);

        /*Insere um produto na lista*/
        Insere(prod, &lista);
    } while(continua == 1);

    /*mostra a quantidade de elementos na lista*/
    int qtd = Quantidade(lista);
    printf("Numero de produtos = %d\n", qtd);

    /*Imprime a lista*/
    ImprimeLista(lista);

    return 0;
}